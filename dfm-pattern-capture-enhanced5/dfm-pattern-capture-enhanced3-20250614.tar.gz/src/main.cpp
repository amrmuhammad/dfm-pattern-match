#include "DFMPatternCaptureApplication.h"

int main(int argc, char* argv[]) {
    DFMPatternCaptureApplication app;
    return app.run(argc, argv);
}
